package com.appcontrol.app_bomba

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.URL
import kotlin.random.Random

class MonitoringService : Service() {

    // Estados de alerta
    private var alertaPozoBajo = false
    private var alertaPozomuyBajo = false
    private var alertaTanqueBajo = false
    private var alertaTanquemuyBajo = false
    private var alertaConexion = false
    private var alertaTanqueLleno = false
    private var alertaTanqueCero = false
    private var alertaPozoCero = false

    // Último estado recibido (para detectar cambios)
    private var ultimoNivelPozo = -1
    private var ultimoNivelTanque = -1

    private var ultimoMinPozo = -1
    private var ultimoMinTanque = -1
    private var ultimaConexionPozo = true
    private var ultimaBomba = false
    private var ultimoModo = ""

    private val scope = CoroutineScope(Dispatchers.IO)
    private var isRunning = true


    override fun onCreate() {
        super.onCreate()
        Log.d("MONITOR_DEBUG", "🔥 Servicio iniciado")
        startForegroundService()
        startMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("MONITOR_DEBUG", "🟢 onStartCommand ejecutado")
        return START_STICKY
    }

    private fun startForegroundService() {

        val channelId = "monitor_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Monitoreo Sistema Bomba",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Bomba")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()

        startForeground(1, notification)
    }


    private fun startMonitoring() {
        scope.launch {

            val prefs = getSharedPreferences("app_bomba_prefs", Context.MODE_PRIVATE)

            while (isRunning) {

                try {
                    val modoConexion = prefs.getString("modo_conexion", "local")
                    val ip = prefs.getString("local_ip", null)
                    val token = prefs.getString("local_token", null)
                    val auth = prefs.getString("auth_token", null)

                    val url = when (modoConexion) {
                        "local" ->
                            if (ip != null && token != null)
                                "http://$ip/api/datos?auth=$token" else null

                        "internet" ->
                            if (auth != null)
                                "https://appbomba.onrender.com/api/render/status?auth=$auth" else null

                        else -> null
                    }

                    if (url != null) {
                        val connection = URL(url).openConnection() as java.net.HttpURLConnection
                        connection.connectTimeout = 5000
                        connection.readTimeout = 5000
                        connection.requestMethod = "GET"

                        val response = connection.inputStream
                            .bufferedReader()
                            .use { it.readText() }

                        connection.disconnect()

                        val json = JSONObject(response)
                        val datos = if (json.has("datos")) json.getJSONObject("datos") else json

                        evaluarAlertas(datos)
                    }

                } catch (e: Exception) {
                    Log.e("MONITOR_DEBUG", "❌ Error en monitoreo", e)
                }

                delay(10_000)
            }
        }
    }


    // ============================================================
    //                    EVALUAR ALERTAS
    // ============================================================
    private fun evaluarAlertas(datos: JSONObject) {

        val nivelPozo = datos.optInt("nivel_pozo", -1)
        val nivelTanque = datos.optInt("nivel_tanque", -1)
        val conexionPozo = datos.optBoolean("conexion_pozo", true)
        val modo = datos.optString("modo", "")
        val bomba = datos.optBoolean("bomba", false)
        val maxTanque = datos.optInt("max_tanque", 100)
        val min_Pozo = datos.optInt("min_pozo", 0)
        val min_Tanque = datos.optInt("min_tanque", 0)

        // Detectar cambios reales
        val huboCambios =
            nivelPozo != ultimoNivelPozo ||
                    nivelTanque != ultimoNivelTanque ||
                    conexionPozo != ultimaConexionPozo ||
                    bomba != ultimaBomba ||
                    modo != ultimoModo ||
                    min_Pozo != ultimoMinPozo ||
                    min_Tanque != ultimoMinTanque

        if (!huboCambios) return


        // ============================================================
        //               🔔 NOTIFICACIÓN: CAMBIO DE MODO
        // ============================================================
        if (ultimoModo != "" && ultimoModo != modo) {
            val titulo = "Modo cambiado"
            val cuerpo = if (modo == "AUTO")
                "El sistema cambió a modo AUTOMÁTICO"
            else
                "El sistema cambió a modo MANUAL"

            notificar(titulo, cuerpo)
        }


        // Guardar nuevos estados
        ultimoNivelPozo = nivelPozo
        ultimoNivelTanque = nivelTanque
        ultimoMinPozo = min_Pozo
        ultimoMinTanque = min_Tanque
        ultimaConexionPozo = conexionPozo
        ultimaBomba = bomba
        ultimoModo = modo


        val estadoBomba = if (bomba) "encendida" else "apagada"


        // ============================================================
        //                         POZO
        // ============================================================
        if (nivelPozo == min_Pozo && !alertaPozoBajo) {
            notificar("Pozo bajo", "El pozo alcanzó su nivel mínimo ($min_Pozo%). La bomba está $estadoBomba.")
            alertaPozoBajo = true
        } else if (nivelPozo != min_Pozo) alertaPozoBajo = false


        if (nivelPozo > 0 && nivelPozo < min_Pozo && !alertaPozomuyBajo) {
            notificar(
                "Pozo muy bajo",
                "El pozo está por debajo de su nivel mínimo ($min_Pozo%). La bomba está $estadoBomba."
            )
            alertaPozomuyBajo = true
        } else if (nivelPozo >= min_Pozo) alertaPozomuyBajo = false


        if (nivelPozo == 0 && !alertaPozoCero) {
            notificar("Error de Sensor", "El sensor del pozo podría estar fallando, nivel actual: $nivelPozo%.")
            alertaPozoCero = true
        } else if (nivelPozo > 0) alertaPozoCero = false


        // ============================================================
        //                        TANQUE
        // ============================================================
        if (nivelTanque == min_Tanque && !alertaTanqueBajo) {
            notificar("Tanque bajo", "El tanque alcanzó su nivel mínimo ($min_Tanque%). La bomba está $estadoBomba.")
            alertaTanqueBajo = true
        } else if (nivelTanque != min_Tanque) alertaTanqueBajo = false


        if (nivelTanque > 0 && nivelTanque < min_Tanque && !alertaTanquemuyBajo) {
            notificar("Tanque muy Bajo", "El tanque está por debajo de su nivel mínimo ($min_Tanque%). La bomba está $estadoBomba.")
            alertaTanquemuyBajo = true
        } else if (nivelTanque >= min_Tanque) alertaTanquemuyBajo = false


        if (nivelTanque == 0 && !alertaTanqueCero) {
            notificar("Error de Sensor", "El sensor del tanque podría estar fallando, nivel actual: $nivelTanque%. Posible error.")
            alertaTanqueCero = true
        } else if (nivelTanque > 0) alertaTanqueCero = false


        if (nivelTanque >= maxTanque && !alertaTanqueLleno) {
            notificar("Tanque Lleno", "El tanque alcanzó su capacidad máxima.")
            alertaTanqueLleno = true
        } else if (nivelTanque < maxTanque) alertaTanqueLleno = false


        // ============================================================
        //                    CONEXIÓN PERDIDA
        // ============================================================
        if (!conexionPozo && !alertaConexion) {
            notificar("Sin conexión", "Se ha perdido la conexión con el pozo. La bomba se mantendrá apagada por seguridad.")
            alertaConexion = true
        } else if (conexionPozo) alertaConexion = false


        // ============================================================
        //                   MODO MANUAL
        // ============================================================
        if (modo == "MANUAL" && bomba) {
            notificar("Bomba Encendida", "La bomba fue encendida desde modo manual.")
        }
        if (modo == "MANUAL" && !bomba) {
            notificar("Bomba Apagada", "La bomba fue apagada desde modo manual.")
        }
    }


    // ============================================================
    //                  NOTIFICAR CON TITULO
    // ============================================================
    private fun notificar(titulo: String, mensaje: String) {

        val channelId = "alert_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Alertas Sistema",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(titulo)
            .setContentText(mensaje)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(Random.nextInt(), notification)
    }


    override fun onBind(intent: Intent?): IBinder? = null


    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        scope.cancel()
    }
}