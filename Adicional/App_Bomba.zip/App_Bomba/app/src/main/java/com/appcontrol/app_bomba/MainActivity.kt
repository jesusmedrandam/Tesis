package com.appcontrol.app_bomba

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.OnBackPressedCallback
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.appcontrol.app_bomba.ui.theme.App_BombaTheme
import android.content.Intent
import androidx.core.content.ContextCompat


class MainActivity : ComponentActivity() {

    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        // 🔵 Splash moderno
        installSplashScreen()

        super.onCreate(savedInstanceState)
        // 🔥 Obtener token FCM al iniciar app
        com.google.firebase.messaging.FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    android.util.Log.d("FCM_DEBUG", "TOKEN: $token")
                    TokenSender.enviarToken(this, token)
                } else {
                    android.util.Log.e("FCM_DEBUG", "Error obteniendo token")
                }
            }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                1001
            )
        }

        // 🔔 Iniciar servicio de monitoreo
        val serviceIntent = Intent(this, MonitoringService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)


        // 🔵 Barras del sistema visibles
        WindowCompat.setDecorFitsSystemWindows(window, true)

        val colorHex = "#b3d9ff"
        window.statusBarColor = Color.parseColor(colorHex)
        window.navigationBarColor = Color.parseColor(colorHex)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val prefs = getSharedPreferences("app_bomba_prefs", MODE_PRIVATE)

        val ip = prefs.getString("local_ip", null)
        val token = prefs.getString("local_token", null)

        val startPage =
            if (ip != null && token != null)
                "file:///android_asset/panel_local.html"
            else
                "file:///android_asset/home.html"

        setContent {
            App_BombaTheme {

                // 🔴 FORZAR FONDO BLANCO EN COMPOSE
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ComposeColor.White)
                ) {
                    WebViewScreen(startPage) { w ->
                        web = w
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {

                    val w = web ?: return
                    val currentUrl = w.url ?: ""

                    when {
                        currentUrl.contains("configuracion_local.html") -> {
                            w.loadUrl("file:///android_asset/panel_local.html")
                        }
                        currentUrl.contains("configuracion.html") -> {
                            w.loadUrl("file:///android_asset/panel.html")
                        }
                        w.canGoBack() -> w.goBack()
                        else -> finish()
                    }
                }
            }
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    startPage: String,
    onWebViewReady: (WebView) -> Unit
) {

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {

                onWebViewReady(this)

                // 🔴 FORZAR FONDO BLANCO EN WEBVIEW
                setBackgroundColor(Color.WHITE)

                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.mixedContentMode =
                    WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                // 🔒 Desactivar zoom
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false

                addJavascriptInterface(
                    AndroidStore(context),
                    "AndroidStore"
                )

                webChromeClient = WebChromeClient()

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {

                        val url = request?.url.toString()

                        if (url.startsWith("http://") ||
                            url.startsWith("https://")
                        ) return false

                        if (url.startsWith("file:///android_asset/")) {
                            view?.loadUrl(url)
                            return true
                        }

                        return false
                    }
                }

                loadUrl(startPage)
            }
        }
    )
}
