package com.appcontrol.app_bomba

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object TokenSender {

    fun enviarToken(context: Context, token: String) {

        GlobalScope.launch(Dispatchers.IO) {
            try {

                val url = URL("https://appbomba.onrender.com/api/render/register-token?auth=A9F3K2X7")
                val connection = url.openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true

                val json = JSONObject()
                json.put("token", token)

                connection.outputStream.use {
                    it.write(json.toString().toByteArray())
                }

                val response = connection.inputStream.bufferedReader().use {
                    it.readText()
                }

                Log.d("FCM_DEBUG", "Token enviado al servidor")

                connection.disconnect()

            } catch (e: Exception) {
                Log.e("FCM_DEBUG", "Error enviando token", e)
            }
        }
    }
}
